## Excel Addin for saving Unicode CSV files
Fork from [jaimonmathew/Unicode-CSV-Addin]

This version uses system wide delimiter for saving CSV files (set in Control Panel/Region and Language/Formats/Additional Settings/List separator).

After compile install with clicking on **UnicodeCSVAddin.vsto**.  
Addin toolbar will appear in Excel under tab "Add-Ins".  
Uninstall from Control Panel/Programs and Features.

For more details please see Jaimon's blog at 
[An Excel Addin to work with Unicode CSV files].

[jaimonmathew/Unicode-CSV-Addin]: https://github.com/jaimonmathew/Unicode-CSV-Addin
[An Excel Addin to work with Unicode CSV files]: http://jaimonmathew.wordpress.com/2011/08/23/excel_addin_to_work_with_unicode_csv/